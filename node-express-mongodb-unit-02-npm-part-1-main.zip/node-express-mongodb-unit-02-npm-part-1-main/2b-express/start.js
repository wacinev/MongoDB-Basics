/*
    0a. In terminal, initialize the project:
    npm init -y
*/

/*
    0b. In terminal, install the express module using the following command:
    npm install express
*/

/*
    1. Import the express module, and prepare a ready-to-use variable for it
*/

/*
    4. Set up a response to localhost:3000/
*/

/*
    5. Set up a response to localhost:3000/about
*/

/*
    6. Set up a response to localhost:3000/*
*/

/*
    2. Set the Port we want to use
*/

/*
    3. Set the application to begin listening / begin spinning the server
*/
