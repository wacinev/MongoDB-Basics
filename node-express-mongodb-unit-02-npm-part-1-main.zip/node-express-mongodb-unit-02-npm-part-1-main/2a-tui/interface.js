// Add your interface code below!

// 1. Import the object from logic.js that contains the functions you need.

// 2. Grab the variables you'll need from the user's input (process.argv).

// 3. Call the function that will convert the temperature, passing in the user's input.

// 4. Print the result to the console.